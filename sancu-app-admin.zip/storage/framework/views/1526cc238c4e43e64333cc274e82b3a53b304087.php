

<?php $__env->startSection('content'); ?>
    
<div class="section-header">
    <h1><?php echo e($title); ?></h1>
</div>

<?php if(session('update_berhasil')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('update_berhasil')); ?>

    </div>
<?php endif; ?>

<div class="row d-flex align-items-center justify-content-center">
    <div class="col-8 p-4 bg-white">
        <h4 class="text-center mb-4">Data Template Whatsapp</h4>

        <form action="" method="post">
            <?php echo csrf_field(); ?>

            
            <?php $__currentLoopData = $whatsapps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whatsapp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__errorArgs = ['<?php echo e($whatsapp->id); ?>'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group row">
                    <label for="<?php echo e($whatsapp->id); ?>" class="col-sm-3 col-form-label"><?php echo e($whatsapp->nama); ?></label>
                    <div class="col-sm-9">
                        <textarea class="form-control" id="<?php echo e($whatsapp->id); ?>" name="<?php echo e($whatsapp->id); ?>" placeholder="Template menunggu ongkir" rows="3" required value="<?php echo e($whatsapp->text); ?>"><?php echo e($whatsapp->text); ?></textarea> 
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

            <div class="form-group row">
                <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Update</button>
                <a class="btn btn-danger" href="<?php echo e(url()->previous()); ?>">Kembali</a>
                </div>
            </div>
            
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sancu-app-admin\resources\views/whatsapp.blade.php ENDPATH**/ ?>