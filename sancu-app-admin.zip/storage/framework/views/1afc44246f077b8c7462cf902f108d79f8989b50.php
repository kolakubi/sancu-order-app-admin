

<?php $__env->startSection('content'); ?>

    <div class="section-header">
        <h1><?php echo e($title); ?></h1>
    </div>

    <table class="table" id="my_datatable">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nama</th>
                <th>Size</th>
                <th>Merk</th>
                <th>Keterangan</th>
                <th>Tanggal</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $data_log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->nama_produk); ?></td>
                <td><?php echo e($item->size); ?></td>
                <td><?php echo e($item->nama_category); ?></td>
                <td><?php echo e($item->keterangan); ?></td>
                <td><?php echo e($item->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sancu-app-admin\resources\views/log_item.blade.php ENDPATH**/ ?>