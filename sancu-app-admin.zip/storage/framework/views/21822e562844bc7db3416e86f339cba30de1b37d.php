

<?php $__env->startSection('content'); ?>

    <div class="section-header">
        <h1><?php echo e($title); ?></h1>
    </div>

    
    <div class="row p-3 bg-white">
        <div class="col-12"><h6 class="text-black">Item terjual hari ini</h6></div>

        
        <div class="col-2">
            <div class="card bg-primary">
                <div class="card-header">
                Sancu
                </div>
                <div class="card-body">
                <h3 class="card-title"><?php echo e($item_sancu); ?></h3>
                <p class="card-text">pasang</p>
                </div>
            </div>
        </div>

        
        <div class="col-2">
            <div class="card bg-success">
                <div class="card-header">
                Boncu
                </div>
                <div class="card-body">
                <h3 class="card-title"><?php echo e($item_boncu); ?></h3>
                <p class="card-text">pasang</p>
                </div>
            </div>
        </div>

        
        <div class="col-2">
            <div class="card bg-danger">
                <div class="card-header">
                Pretty
                </div>
                <div class="card-body">
                <h3 class="card-title"><?php echo e($item_pretty); ?></h3>
                <p class="card-text">pasang</p>
                </div>
            </div>
        </div>

        
        <div class="col-2">
            <div class="card bg-dark">
                <div class="card-header">
                Xtreme
                </div>
                <div class="card-body">
                <h3 class="card-title"><?php echo e($item_xtreme); ?></h3>
                <p class="card-text">pasang</p>
                </div>
            </div>
        </div>

        
        <div class="col-2">
            <div class="card bg-secondary">
                <div class="card-header">
                Lainnya
                </div>
                <div class="card-body">
                <h3 class="card-title"><?php echo e($item_lainnya); ?></h3>
                <p class="card-text">pasang</p>
                </div>
            </div>
        </div>

    </div>

    
    <div class="row mt-3 p-3 bg-white">
        <div class="col-4">
            <h6>Total penjualan hari ini</h6>
            <div class="card bg-info">
                <div class="card-header">
                    Penjualan
                </div>
                <div class="card-body">
                    <h3 class="card-title">Rp<?php echo e(number_format($uang_penjualan, 0)); ?></h3>
                    <p class="card-text">Rupiah</p>
                </div>
            </div>
        </div>

        <div class="col-4">
            <h6>Total order hari ini</h6>
            <div class="card bg-light">
                <div class="card-header">
                    Order
                </div>
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($total_order); ?></h3>
                    <p class="card-text">Order</p>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sancu-app-admin\resources\views/dashboard.blade.php ENDPATH**/ ?>