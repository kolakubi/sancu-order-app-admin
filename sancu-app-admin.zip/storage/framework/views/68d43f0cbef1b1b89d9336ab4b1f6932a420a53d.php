

<?php $__env->startSection('content'); ?>
<div class="section-header">
    <h1>Orders # <?php echo e($id_order); ?> <?php echo e($agen->name); ?></h1>
</div>



<?php
    $asd = 0;
    $sub_harga_per_category = 0;
    $total_jumlah_harga = 0;
    $total_berat = 0;
    $total_jumlah_produk = 0;
    $potongan_harga_langsung = (int)$alamat->potongan_harga_langsung;
?>

<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
        $total_jumlah_harga += ($order->harga_produk*$order->jumlah_produk);
        $total_jumlah_produk += $order->jumlah_produk;
        $total_berat += ($order->berat*$order->jumlah_produk);
    ?>

    
    
    
    <?php if($order->id_category != $asd): ?>

        <?php
            $asd = $order->id_category;
            $sub_harga_per_category = 0;
        ?>

        <div class="card card-info card-outline">
            <div class="card-header" style="min-height: 0; padding: 10px 28px">  
                <h4 class="text-dark"><?php echo e($order->nama_category); ?></h4>
                
            </div>
            
            <div class="card-body">
                <table class="table table-hover table-sm">
                    <thead class="bg-info text-white">
                        <tr style="background-color: rgba(0,0,0,0.3)">
                            <th>No</th>
                            <th>Model</th>
                            <th>Size</th>
                            <th>Jumlah (pack)</th>
                            <th>Jmlh Harga</th>
                        </tr>
                    </thead>
                    <tbody>
    <?php endif; ?>
        <?php
            $sub_harga_per_category += ($order->harga_produk*$order->jumlah_produk);
        ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($order->nama_produk); ?></td>
            <td><?php echo e($order->size); ?></td>
            <td><?php echo e($order->jumlah_produk); ?></td>
            <td>Rp<?php echo e(number_format($order->jumlah_produk*$order->harga_produk, 0, '.', ',')); ?></td>
        </tr>

        
        
        <?php if(isset($orders[$key+1])): ?>
            <?php if($orders[$key+1]->id_category != $asd): ?>
                </tbody>
                </table>
                </div><!-- end card body -->
                <div class="card-footer text-right border-top">
                    <h6 class="text-dark">
                        Total Pembelian <?php echo e($order->nama_category); ?>:
                        <strong>
                            Rp<?php echo e(number_format($sub_harga_per_category, '0', '.', ',')); ?>

                        </strong>
                    </h6>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?>  

        
        
        <?php if($loop->last): ?>
            </tbody>
            </table>
            </div><!-- end card body -->
            <div class="card-footer text-right border-top">
                <h6 class="text-dark">
                    Total Pembelian <?php echo e($order->nama_category); ?>:
                    <strong>
                        Rp<?php echo e(number_format($sub_harga_per_category, '0', '.', ',')); ?>

                    </strong>
                </h6>
            </div>
        </div>
        <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






<div class="card card-info card-outline">
    <div class="card-header">  
        <h4>Detail Order</h4>
    </div>
    <div class="card-body">
        <table class="table table-sm table-striped">
            <tbody>
                
                <?php if($alamat->status == "1" || $alamat->status == "2"): ?>
                <tr>
                    <td style="width: 25%">Batalkan Pesanan</td>
                    <td>
                        <a id="batalkan_order" data-idorder="<?php echo e($id_order); ?>" onclick="batalkan_pesanan(this)" href="#" class="btn btn-danger">Batalkan Pesanan</a>
                    </td>
                </tr>
                <?php endif; ?>
                <tr style="border-bottom: 2px solid black;">
                    <td>Cetak Detail Packing</td>
                    <td>
                        <a href="/printdetailpacking/<?php echo e($id_order); ?>" target="_blank" class="btn btn-info">Cetak Detail Packing</a>
                    </td>
                </tr>
                <tr>
                    <td>Total Pembelian</td>
                    <td>: Rp<?php echo e(number_format($total_jumlah_harga, '0', '.', ',')); ?>

                    </td>
                </tr>
                <tr>
                    <td>Total Berat</td>
                    <td>: <?php echo e(number_format($total_berat, 0, '.', ',')); ?>g</td>
                </tr>
                <tr>
                    <td>Diskon/Kupon</td>
                    <td>: <?php echo e($coupon != null ? $coupon->name : '-'); ?></td>
                </tr>
                <tr>
                    <td>Potongan harga</td>
                    <td>: Rp<?php echo e($coupon != null ? number_format($coupon->potongan, '0', '.', ',') : 0); ?> / psg</td>
                </tr>
                <tr>
                    <td>Total potongan harga Kupon</td>
                    <td>: Rp<?php echo e($coupon != null ? 
                        number_format(($total_jumlah_produk)*$coupon->potongan, '0', '.', ',') : 0); ?></td>
                </tr>

                
                <tr style="border-bottom: 2px solid black;">
                    <td>Alamat pengiriman</td>
                    <td>:
                        <?php echo e($alamat->nama_lengkap); ?><br>
                        <?php echo e($alamat->telepon); ?><br>
                        <?php echo e($alamat->alamat_lengkap); ?><br>
                        <?php echo e($alamat->kecamatan); ?>, <?php echo e($alamat->kota_kabupaten); ?>, <?php echo e($alamat->propinsi); ?>, <?php echo e($alamat->kode_pos); ?>

                    </td>
                </tr>

                
                <form action="<?php echo e(route('update_ongkir')); ?>" method="post" class="row">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="orders_id" value="<?php echo e($id_order); ?>">
                    <tr>
                        <td>Ongkir</td>
                        <td>
                            <?php $__errorArgs = ['ongkir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            <div class="col-8">
                                <input type="text" placeholder="Input Ongkir" value="<?php echo e($ongkir); ?>" class="form-control" name="ongkir" <?php if($agen->status == '5' || $agen->status == '0'): ?> disabled  <?php endif; ?>>
                            </div> 
                        </td>
                    </tr>
                    <tr>
                        <td>Ekspedisi</td>
                        <td>
                            <?php $__errorArgs = ['ekspedisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="col-8">
                                <input type="text" placeholder="Input ekspedisi" value="<?php echo e($alamat->ekspedisi); ?>" class="form-control" name="ekspedisi" <?php if($agen->status == '5' || $agen->status == '0'): ?> disabled  <?php endif; ?>>
                            </div>
                        </td>
                    </tr>
                    <tr style="border-bottom: 2px solid black;">
                        <td></td>
                        <td>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-info" <?php if($agen->status == '5' || $agen->status == '0'): ?> disabled  <?php endif; ?>>Update</button>
                            </div>     
                        </td>
                    </tr>
                </form>

                
                <form action="<?php echo e(route('update_potongan_harga_langsung')); ?>" method="post" class="row">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="orders_id" value="<?php echo e($id_order); ?>">
                    <tr>
                        <td>Potongan harga langsung</td>
                        <td>
                            <?php $__errorArgs = ['potongan_harga_langsung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            <div class="col-8">
                                <input type="text" placeholder="Input Potongan harga" value="<?php echo e($potongan_harga_langsung); ?>" class="form-control" name="potongan_harga_langsung" <?php if($agen->status == '5' || $agen->status == '0'): ?> disabled  <?php endif; ?>>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Keterangan</td>
                        <td>
                            <?php $__errorArgs = ['keterangan_potongan_harga_langsung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            <div class="col-8">
                                <input type="text" placeholder="keterangan porongan harga..." value="<?php echo e($alamat->keterangan_potongan_harga_langsung); ?>" class="form-control" name="keterangan_potongan_harga_langsung" <?php if($agen->status == '5' || $agen->status == '0'): ?> disabled  <?php endif; ?>>
                            </div>
                        </td>
                    </tr>
                    <tr style="border-bottom: 2px solid black;">
                        <td></td>
                        <td>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-info" <?php if($agen->status == '5' || $agen->status == '0'): ?> disabled  <?php endif; ?>>Update</button>
                            </div>
                        </td>
                    </tr>
                </form>

                
                <tr style="border-bottom: 2px solid black;">
                    <td>Grand Total</td>
                    <td class="text-dark">
                        : Rp
                            <?php echo e(number_format(
                                (
                                    $total_jumlah_harga
                                )
                                +
                                $ongkir
                                -
                                (
                                    $coupon != null ? 
                                    (
                                        $total_jumlah_produk
                                    )
                                    *
                                    $coupon->potongan : 0
                                )
                                -
                                $potongan_harga_langsung
                                , '0'
                            )); ?>

                    </td>
                </tr>

                
                <?php if($agen->status >= '3'): ?>
                <tr style="border-bottom: 2px solid black;">
                    <td>Bukti Pembayaran</td>
                    <td>
                        <p>klik gambar untuk memperbesar</p>
                        <a href="<?php echo e($client_host); ?><?php echo e($agen->bukti_bayar); ?>" target="_blank">
                            <img class="img-thumbnail" style="max-width: 200px;" src="<?php echo e($client_host); ?><?php echo e($agen->bukti_bayar); ?>" alt="">
                        </a>
                    </td>
                </tr>
                
                <tr>
                    <td>Resi Pengiriman</td>
                    <td>
                        <form action="<?php echo e(route('update_resi')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="orders_id" value="<?php echo e($id_order); ?>">
                            <input class="form-control" type="file" name="file_resi" required <?php if($agen->status == '5' || $agen->status == '0'): ?> disabled  <?php endif; ?>>

                            <?php $__errorArgs = ['file_resi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <span>Max Size: 2MB</span>
                            <br>
                            <br>

                            <button type="submit" class="btn btn-success" <?php if($agen->status == '5' || $agen->status == '0'): ?> disabled  <?php endif; ?>>Upload Resi Pengiriman</button>
                        </form>

                        <?php if($agen->status >= '4'): ?>
                            <div class="col-12 mt-4">
                                <img class="img-thumbnail" src="/storage/<?php echo e($agen->resi); ?>" alt="" style="max-width: 300px">
                            </div>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div> <!-- end card-body -->
</div>


<script src="/assets/sweet-alert/sweetalert2.all.min.js"></script>
<script>
    let token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    function batalkan_pesanan(elem){
        elem.preventDevault;
        let idPesanan = elem.dataset.idorder;

        Swal.fire({
            icon: 'question',
            title: 'Yakin ingin membatalkan order ini',
            showDenyButton: true,
            confirmButtonText: 'Ya',
            denyButtonText: `Tidak`,
        }).then((result) => {
            if (result.isConfirmed) {
                // ajax ke pengecekan stok
                fetch("/orders/batal", {
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json, text-plain, */*",
                        "X-Requested-With": "XMLHttpRequest",
                        "X-CSRF-TOKEN": token
                        },
                    method: "POST", 
                    credentials: "same-origin",
                    body: idPesanan
                })
                .then(response => response.json())
                .then(data => {

                    if(data.status == '200'){
                        Swal.fire('Saved!', '', 'success')
                        .then((result)=>{
                            location.reload();
                        })
                    }
                    else{
                        Swal.fire({
                            icon: 'error',
                            title: 'Ada kesalahan',
                        })
                    }
                    console.log(data);
                })
            }
        })
    }
    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sancu-app-admin\resources\views/order_details.blade.php ENDPATH**/ ?>