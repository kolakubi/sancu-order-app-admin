

<?php $__env->startSection('content'); ?>
    
<div class="section-header">
    <h1>Import Stok</h1>
</div>

<div class="row">
    <form action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleFormControlFile1">Input File CSV</label>
            <input type="file" class="form-control-file" id="exampleFormControlFile1" name="file-import" required>
        </div>
        <button class="btn btn-primary" type="submit">Import</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sancu-app-admin\resources\views/import_stok.blade.php ENDPATH**/ ?>