

<?php $__env->startSection('content'); ?>
    
<div class="section-header">
    <h1><?php echo e($title); ?></h1>
</div>

<div class="row d-flex align-items-center justify-content-center">
    <div class="col-6 p-4 bg-white">
        <h4 class="text-center mb-4">Data Category</h4>

        <form action="" method="post">
            <?php echo csrf_field(); ?>

            <?php if(session('error_nama')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error_nama')); ?>

                </div>
            <?php endif; ?>
            <div class="form-group row">
                <label for="nama_category" class="col-sm-3 col-form-label">Nama (unique)</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="nama_category" name="nama_category" placeholder="Nama category..." required>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a class="btn btn-danger" href="<?php echo e(url()->previous()); ?>">Kembali</a>
                </div>
            </div>
            
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sancu-app-admin\resources\views/category_add.blade.php ENDPATH**/ ?>