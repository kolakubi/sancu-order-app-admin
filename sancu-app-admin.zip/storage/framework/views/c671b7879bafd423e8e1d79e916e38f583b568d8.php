<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Resi Pengiriman</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body{
            font-size: 10px!important;
        }
        .container{
            max-width: 900px;
        }
    </style>
</head>
<body>

    <div class="container">
        
        <div class="row">
            <div class="col-8">

                <div class="row">
                    <div class="col-6">
                        <table class="table table-sm">
                            <tbody>
                                <tr>
                                    <th>No Order</th>
                                    <td>#<?php echo e($id_order); ?></td>
                                </tr>
                                <tr>
                                    <th>Tanggal</th>
                                    <td>20 Februari 2022</td>
                                </tr>
                                <tr>
                                    <th>Nama</th>
                                    <td><?php echo e($agen->name); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="col-6">
                        <table class="table table-sm">
                            <tbody>
                                <tr>
                                    <th>Alamat</th>
                                    <td>Jalan Persahabatan VI no 3-4, Ciracas, Jakarta Timur</td>
                                </tr>
                                <tr>
                                    <th>Telepon</th>
                                    <td>0856-1111-2222</td>
                                </tr>
                                <tr>
                                    <th>Ekspedisi</th>
                                    <td>Indah Cargo</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
            <div class="col-4 d-flex align-items-center justify-content-center">
                <img src="/sancu_assets/img/logo-sancu-mini.png" alt="" class="img">
            </div>
        </div>

        
        <?php
            $jumlah_harga_sancu = 0;
            $jumlah_item_sancu = 0;
        ?>

        <?php if($data_sancu->count() > 0): ?>
        <div class="row">
            <h4 class="">Sancu</h4>
            <div class="col-12">
                <table class="table table-sm table-bordered">
                    <thead style="background: rgba(0,0,0,0.1);">
                        <tr>
                            <th>No</th>
                            <th>Model</th>
                            <th>Size</th>
                            <th>Jumlah (pack)</th>
                            <th>Harga</th>
                            <th>Check 1</th>
                            <th>Check 2</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_sancu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sancu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $jumlah_harga_sancu += ($sancu->jumlah_produk*$sancu->harga_produk);
                            $jumlah_item_sancu += $sancu->jumlah_produk;
                        ?>
                        
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($sancu->nama_produk); ?></td>
                            <td><?php echo e($sancu->size); ?></td>
                            <td><?php echo e($sancu->jumlah_produk); ?></td>
                            <td>Rp <?php echo e(number_format($sancu->harga_produk*$sancu->jumlah_produk, 0)); ?></td>
                            <td><i class="bi bi-square"></i></td>
                            <td><i class="bi bi-square"></i></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><strong><?php echo e($jumlah_item_sancu); ?></strong></td>
                            <td><strong>Rp <?php echo e(number_format($jumlah_harga_sancu, 0)); ?></strong></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        
        <?php
            $jumlah_harga_boncu = 0;
            $jumlah_item_boncu = 0;
        ?>

        <?php if($data_boncu->count() > 0): ?>
        <div class="row">
            <h4 class="">Boncu</h4>
            <div class="col-12">
                <table class="table table-sm table-bordered">
                    <thead style="background: rgba(0,0,0,0.1);">
                        <tr>
                            <th>No</th>
                            <th>Model</th>
                            <th>Size</th>
                            <th>Jumlah (pack)</th>
                            <th>Harga</th>
                            <th>Check 1</th>
                            <th>Check 2</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_boncu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boncu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $jumlah_harga_boncu += ($boncu->jumlah_produk*$boncu->harga_produk);
                            $jumlah_item_boncu += $boncu->jumlah_produk;
                        ?>
                        
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($boncu->nama_produk); ?></td>
                            <td><?php echo e($boncu->size); ?></td>
                            <td><?php echo e($boncu->jumlah_produk); ?></td>
                            <td>Rp <?php echo e(number_format($boncu->harga_produk*$boncu->jumlah_produk, 0)); ?></td>
                            <td><i class="bi bi-square"></i></td>
                            <td><i class="bi bi-square"></i></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><strong><?php echo e($jumlah_item_boncu); ?></strong></td>
                            <td><strong>Rp <?php echo e(number_format($jumlah_harga_boncu, 0)); ?></strong></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        
        <?php
            $jumlah_harga_pretty = 0;
            $jumlah_item_pretty = 0;
        ?>

        <?php if($data_pretty->count() > 0): ?>
        <div class="row">
            <h4 class="">Pretty</h4>
            <div class="col-12">
                <table class="table table-sm table-bordered">
                    <thead style="background: rgba(0,0,0,0.1);">
                        <tr>
                            <th>No</th>
                            <th>Model</th>
                            <th>Size</th>
                            <th>Jumlah (pack)</th>
                            <th>Harga</th>
                            <th>Check 1</th>
                            <th>Check 2</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_pretty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pretty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $jumlah_harga_pretty += ($pretty->jumlah_produk*$pretty->harga_produk);
                            $jumlah_item_pretty += $pretty->jumlah_produk;
                        ?>
                        
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($pretty->nama_produk); ?></td>
                            <td><?php echo e($pretty->size); ?></td>
                            <td><?php echo e($pretty->jumlah_produk); ?></td>
                            <td>Rp <?php echo e(number_format($pretty->harga_produk*$pretty->jumlah_produk, 0)); ?></td>
                            <td><i class="bi bi-square"></i></td>
                            <td><i class="bi bi-square"></i></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><strong><?php echo e($jumlah_item_pretty); ?></strong></td>
                            <td><strong>Rp <?php echo e(number_format($jumlah_harga_pretty, 0)); ?></strong></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        
        <?php
            $jumlah_harga_xtreme = 0;
            $jumlah_item_xtreme = 0;
        ?>

        <?php if($data_xtreme->count() > 0): ?>
        <div class="row">
            <h4 class="">Xtreme</h4>
            <div class="col-12">
                <table class="table table-sm table-bordered">
                    <thead style="background: rgba(0,0,0,0.1);">
                        <tr>
                            <th>No</th>
                            <th>Model</th>
                            <th>Size</th>
                            <th>Jumlah (pack)</th>
                            <th>Harga</th>
                            <th>Check 1</th>
                            <th>Check 2</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_xtreme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $xtreme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $jumlah_harga_xtreme += ($xtreme->jumlah_produk*$xtreme->harga_produk);
                            $jumlah_item_xtreme += $xtreme->jumlah_produk;
                        ?>
                        
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($xtreme->nama_produk); ?></td>
                            <td><?php echo e($xtreme->size); ?></td>
                            <td><?php echo e($xtreme->jumlah_produk); ?></td>
                            <td>Rp <?php echo e(number_format($xtreme->harga_produk*$xtreme->jumlah_produk, 0)); ?></td>
                            <td><i class="bi bi-square"></i></td>
                            <td><i class="bi bi-square"></i></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><strong><?php echo e($jumlah_item_xtreme); ?></strong></td>
                            <td><strong>Rp <?php echo e(number_format($jumlah_harga_xtreme, 0)); ?></strong></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>


        <div class="row mt-4">
            <p class="text-center"><span style="text-decoration: underline">Sancu Creative Indonesia</span><br>
                Kolonel Sugiono No.55 AA, Ngeni, Kepuhkiriman, Kec. Waru, Kabupaten Sidoarjo, Jawa Timur 61256</p>
        </div>

    </div> <!-- end container -->
    
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script>
        window.print();
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\sancu-app-admin\resources\views/print_resi_pengiriman.blade.php ENDPATH**/ ?>