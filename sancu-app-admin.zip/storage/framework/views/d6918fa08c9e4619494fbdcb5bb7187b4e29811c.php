<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div id="app">
    <div class="main-wrapper">

      
      <?php echo $__env->make('partials.main_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      

      
      <?php echo $__env->make('partials.sidebars', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      

      <!-- Main Content -->
      <div class="main-content">
        <section class="section">

          <div class="section-body">

            <?php echo $__env->yieldContent('content'); ?>

          </div>
        </section>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2021 <div class="bullet"></div> Ver 1.0 <div class="bullet"></div> Develope By <a href="#">Malcorp</a>
        </div>
        <div class="footer-right">
          2.3.0
        </div>
      </footer>
    </div>
  </div>

  <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sancu-app-admin\resources\views/main.blade.php ENDPATH**/ ?>