<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Resi Pengiriman</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body{
            font-size: 10px!important;
        }
        .container{
            max-width: 900px;
        }
    </style>
</head>
<body>
    <div class="container">
        
        <div class="row">
            <div class="col-8">
                <div class="row">
                    <div class="col-6">
                        <table class="table table-sm">
                            <tbody>
                                <tr>
                                    <th>No Order</th>
                                    <td>#<?php echo e($id_order); ?></td>
                                </tr>
                                <tr>
                                    <th>Tanggal</th>
                                    <td><?php echo e($orders[0]->created_at); ?></td>
                                </tr>
                                <tr>
                                    <th>Nama</th>
                                    <td><?php echo e($agen->name); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-6">
                        <table class="table table-sm">
                            <tbody>
                                <tr>
                                    <th>Alamat</th>
                                    <td><?php echo e($alamat->alamat_lengkap); ?>, <?php echo e($alamat->kecamatan); ?>, <?php echo e($alamat->kota_kabupaten); ?>, <?php echo e($alamat->propinsi); ?>, <?php echo e($alamat->kode_pos); ?></td>
                                </tr>
                                <tr>
                                    <th>Telepon</th>
                                    <td><?php echo e($alamat->telepon); ?></td>
                                </tr>
                                <tr>
                                    <th>Ekspedisi</th>
                                    <td><?php echo e($alamat->ekspedisi); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-4 d-flex align-items-center justify-content-center">
                <img src="/sancu_assets/img/logo-sancu-mini.png" alt="" class="img">
            </div>
        </div>

        
        <?php
            $asd = 0;
            $sub_harga_per_category = 0;
            $sub_item_per_category = 0;
            $total_jumlah_harga = 0;
            $total_berat = 0;
            $total_jumlah_produk = 0;
        ?>

        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            
            
            <?php if($order->id_category != $asd): ?>

                <?php
                    $asd = $order->id_category;
                    $sub_harga_per_category = 0;   
                    $sub_item_per_category = 0;   
                ?>

                <div class="row">
                    <h4 class=""><?php echo e($order->nama_category); ?></h4>
                    <div class="col-12">
                        <table class="table table-sm table-bordered">
                            <thead style="background: rgba(0,0,0,0.1);">
                                <tr>
                                    <th>No</th>
                                    <th>Model</th>
                                    <th>Size</th>
                                    <th>Jumlah (pack)</th>
                                    <th>Harga</th>
                                    <th>Check 1</th>
                                    <th>Check 2</th>
                                </tr>
                            </thead>
                            <tbody>
            <?php endif; ?>

            <?php
                $sub_harga_per_category += ($order->harga_produk*$order->jumlah_produk);
                $sub_item_per_category += $order->jumlah_produk;
            ?>

            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($order->nama_produk); ?></td>
                <td><?php echo e($order->size); ?></td>
                <td><?php echo e($order->jumlah_produk); ?></td>
                <td>Rp <?php echo e(number_format($order->harga_produk*$order->jumlah_produk, 0)); ?></td>
                <td><i class="bi bi-square"></i></td>
                <td><i class="bi bi-square"></i></td>
            </tr>

            
            
            <?php if(isset($orders[$key+1])): ?>
                <?php if($orders[$key+1]->id_category != $asd): ?>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><strong><?php echo e($sub_item_per_category); ?></strong></td>
                                    <td><strong>Rp <?php echo e(number_format($sub_harga_per_category, 0)); ?></strong></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            
            
            <?php if($loop->last): ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><strong><?php echo e($sub_item_per_category); ?></strong></td>
                            <td><strong>Rp <?php echo e(number_format($sub_harga_per_category, 0)); ?></strong></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
                </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        

        <div class="row mt-4">
            <p class="text-center"><span style="text-decoration: underline">Sancu Creative Indonesia</span><br>
                Kolonel Sugiono No.55 AA, Ngeni, Kepuhkiriman, Kec. Waru, Kabupaten Sidoarjo, Jawa Timur 61256</p>
        </div>

    </div> <!-- end container -->
    
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script>
        window.print();
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\sancu-app-admin\resources\views/print_detail_packing.blade.php ENDPATH**/ ?>